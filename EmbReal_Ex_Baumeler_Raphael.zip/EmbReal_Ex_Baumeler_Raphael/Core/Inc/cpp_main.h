/*
 * cpp_main.h
 *
 *  Created on: Jan 11, 2023
 *      Author: raphael.baumeler
 */

#ifndef INC_CPP_MAIN_H_
#define INC_CPP_MAIN_H_

#pragma once
#ifdef __cplusplus
extern "C" {
#endif

void cpp_main();

#ifdef __cplusplus
}
#endif

#endif /* INC_CPP_MAIN_H_ */
